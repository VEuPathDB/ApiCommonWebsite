package Bio::Graphics::Glyph::connector;

# just a line, for DAS compatibility
use strict;
use Bio::Graphics::Glyph::generic;
use Bio::Graphics::Glyph::line;
use vars '@ISA';
@ISA = 'Bio::Graphics::Glyph::line';
1;

__END__
