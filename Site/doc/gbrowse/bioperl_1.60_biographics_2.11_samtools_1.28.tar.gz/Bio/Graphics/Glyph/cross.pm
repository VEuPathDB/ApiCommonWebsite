package Bio::Graphics::Glyph::cross;

use strict;
use base qw(Bio::Graphics::Glyph::crossbox);

sub my_description {
    "This is identical to the crossbox glyph and is present here for ".
    "DAS compatibility.";
}


1;
